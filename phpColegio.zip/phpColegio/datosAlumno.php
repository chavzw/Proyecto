<?php
session_start();
require 'conexion.php';
if (isset($_SESSION['user_id'])) {
	$records = $conn->prepare('SELECT id,nombre, apellido, correo, password FROM usuarios WHERE id=:id');
	$records->bindParam(':id',$_SESSION['user_id']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = null;

	if (count($results)>0) {
		$user = $results;	
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Datos Alumno </title>
	<link href="https://fonts.googleapis.com/css?family=Mukta" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body> 
	<a href="https://www.facebook.com/Nehemiah-christian-school-284046931951941/"><img src="imagenes/imagencolegio.jpg" style="position: absolute; top: 0; left: 0;" width="120" height="120" align="left"></a>
	<tittle><h2> Nehemiah christian school </h2></tittle>
	<h4> Alumno </h4>
	<?php if(!empty($user)): ?>
		<p align="right"><br> Bienvenido: <?= $user['nombre'],' ', $user['apellido'] ?>
		<br>
		<a href="cerrarsesion.php"> Cerrar Sesión </a>
	</p>
	<?php else:  ?> 
	<?php endif; ?>

	<center><table border="2"> </center>
		<tr>
			<td><a href="notasAlumnos.php"><img src="imagenes/notas.jpg" width="160" height="160" title="Notas de Alumnos"></a></td>
		</tr>
	</table>

</body>
</html>