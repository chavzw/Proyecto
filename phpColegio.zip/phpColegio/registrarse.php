<?php
require 'conexion.php';

$message='';

if (!empty($_POST['correo']) && !empty($_POST['password'])) {
	$sql = "INSERT INTO usuarios (nombre,apellido,correo,password) VALUES (:nombre, :apellido, :correo, :password)";
	$stmt = $conn->prepare($sql);
	$stmt->bindParam(':correo',$_POST['correo']); 
	$stmt->bindParam(':nombre',$_POST['nombre']);
	$stmt->bindParam(':apellido',$_POST['apellido']);
	$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
	$stmt->bindParam(':password',$password); 

	if ($stmt->execute()) {
		$message = '¡Datos ingresados exitosamente!';
	}else{
		$message = '¡Los datos no se han guardado!';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Registrarse </title>
	<link href="https://fonts.googleapis.com/css?family=Mukta" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	<?php require 'partials/header.php' ?>
	<?php 
	if (!empty($message)): ?>
		<p><?= $message?></p>
	<?php endif; 	?>

	<h4> Registrarse. </h4>
	<span> Poseé una cuenta: <a href="login.php"> Iniciar Sesión </a></span>
	<form action="registrarse.php" method="POST">
		<input type="text" name="nombre" placeholder=" Primer nombre ">
		<input type="text" name="apellido" placeholder=" Primer Apellido ">
		<input type="text" name="correo" placeholder=" Pnombrecarnet@cciudaddelgado.edu.sv ">
		<input type="password" name="password" placeholder=" Ingrese su contraseña ">
		<input type="submit" value=" Ingresar ">
	</form>
</body>
</html>