<?php
session_start();
require 'conexion.php';
if (isset($_SESSION['user_id'])) {
	$records = $conn->prepare('SELECT id,nombre, apellido, correo, password FROM usuarios WHERE id=:id');
	$records->bindParam(':id',$_SESSION['user_id']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = null;

	if (count($results)>0) {
		$user = $results;	
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Datos de Alumnos </title>
	<link href="https://fonts.googleapis.com/css?family=Mukta" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	<a href="https://www.facebook.com/Nehemiah-christian-school-284046931951941/"><img src="imagenes/imagencolegio.jpg" style="position: absolute; top: 0; left: 0;" width="120" height="120" align="left"></a>
	<tittle><h2> Nehemiah christian school </h2></tittle>
	<h4> Registro de Alumnos </h4>
	<?php if(!empty($user)): ?>
		<p align="right"><br> Bienvenido: <?= $user['nombre'],' ', $user['apellido'] ?>
		<br>
		<a href="cerrarsesion.php"> Cerrar Sesión </a></br>
		<a href="datosAdmin.php"> Atrás </a>
	</p>
	<?php else:  ?> 
	<?php endif; ?>

		
	<center><table border="1"> </center>
		<tr>
			<td>&nbsp Apellidos &nbsp</td>
			<td>&nbsp Nombres &nbsp</td>
			<td>&nbsp Dirección &nbsp</td>
			<td>&nbsp Telefonos &nbsp</td>
			<td>&nbsp Correo &nbsp</td>
			</tr>

</body>
</html>