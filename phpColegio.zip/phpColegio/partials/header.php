<header>
		<a href="/phpColegio"> Pagina principal de Inicio de Sesión y Registros </a>
	</header>