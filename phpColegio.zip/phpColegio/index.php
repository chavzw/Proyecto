<?php
session_start();
require 'conexion.php';
if (isset($_SESSION['user_id'])) {
	$records = $conn->prepare('SELECT id, correo, password FROM usuarios WHERE id=:id');
	$records->bindParam(':id',$_SESSION['user_id']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$user = null;

	if (count($results)>0) {
		$user = $results;	
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Principal </title>
	<link href="https://fonts.googleapis.com/css?family=Mukta" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	
	<?php require 'partials/header.php' ?>
	<?php if(!empty($user)): ?>
		<br> Bienvenido: <?= $user['correo'] ?>
		<br>Estas satisfactoriamente logeado en el Sistema, ¿ Desea,
		<a href="cerrarsesion.php"> Cerrar Sesión ? </a>
		<?php else:  ?> 
			<h4> Por favor iniciar sesión con el correo de administrador para entrar al sistema o Registrarse si no posee uno </h4>			
			<a href="login.php"><img src="imagenes/login.png" width="120" height="120" title="Login de Administrador"></a>
			<a href="registrarse.php"><img src="imagenes/registrarse.jpg" width="120" height="120" title="Registrarse"></a><br>
			<a href="loginAlumno.php"><img src="imagenes/alumnos.jpg" width="120" height="120" title="Login Alumno"></a>
			<a href="loginMaestro.php"><img src="imagenes/maestros.jpg" width="120" height="120" title="Login Maestros"></a>
		<?php endif; ?>
	</body>
	</html>