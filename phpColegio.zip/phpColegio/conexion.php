<?php
$server   = 'localhost';
$username = 'root';
$password = '';
$database = 'bdproyecto';

try {
	$conn = new PDO("mysql:host=$server;dbname=$database;",$username, $password);
} catch (PDOException $e) {
	die('Conexion Fallida: '.$e->getMessage());
}
?>