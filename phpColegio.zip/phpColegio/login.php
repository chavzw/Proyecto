<?php
session_start();
require 'conexion.php';
if (!empty($_POST['correo']) && !empty($_POST['password'])) {
	$records = $conn->prepare('SELECT id, correo, password FROM usuarios WHERE correo=:correo');
	$records->bindParam(':correo', $_POST['correo']);
	$records->execute();
	$results = $records->fetch(PDO::FETCH_ASSOC);

	$message = '';

	if (count($results)>0 && password_verify($_POST['password'], $results['password'])) {
		$_SESSION['user_id'] = $results['id'];
		header('Location: datosAdmin.php');
	}else{
		$message = 'Lo sentimos, las credenciales no coinciden';
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Login </title>
	<link href="https://fonts.googleapis.com/css?family=Mukta" rel="stylesheet">
	<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
	<?php require 'partials/header.php' ?>
	<h4> Login </h4>
	<br>
	<a href="https://www.facebook.com/Nehemiah-christian-school-284046931951941/"><img src="imagenes/imagencolegio.jpg" style="position: absolute; top: 0; left: 0;" width="120" height="120" align="left"></a>
	<span> No tiene una cuenta: <a href="registrarse.php"> Registrarse </a></span><br><br>
	<?php if (!empty($message)) : ?>
	<p><?= $message ?></p>
	<?php endif; ?>
	<a><h4> Nehemiah christian school </a></h4>
	<form action="login.php" method="POST">
		<input type="text" name="correo" placeholder=" Ingrese su correo ">
		<input type="password" name="password" placeholder=" Ingrese su contraseña ">
		<input type="submit" value=" Ingresar ">
	</form>
</body>
</html>